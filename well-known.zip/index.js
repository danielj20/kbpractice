var timerDiv = document.getElementById("timer")
var subjectDiv = document.getElementById('subject')
var questionDiv = document.getElementById('question')
var answerDiv = document.getElementById('answer')
var textInput = document.getElementById('answer-box')
var isCorrect = document.getElementById('iscorrect')
var darkMode = document.getElementById('darkmode')

var current = "";
var hasBuzzedIn = false;



function fetchQuestion() {
    const Http = new XMLHttpRequest();
    const url='https://kbpractice.com/API/';
    Http.open("GET", url);
    Http.send();

    Http.onreadystatechange = (e) => {
        if (Http.readyState == 4 && Http.status == 200){
            if (Http.responseText){
                current = JSON.parse(Http.responseText);
                readQuestion();
            }
       }
    }
}

function readQuestion() {
    clearQuestion();
    subjectDiv.innerHTML = current["subject"];
    questionArray = current["question"].split(" ");
    var i = 0;
    reading = setInterval(function() {
        if(i < questionArray.length) {
            questionDiv.innerHTML += questionArray[i] + " ";
        } else {
            questionDone();
        };
        i++;
    }, 250);
}

function clearQuestion() {
    hasBuzzedIn = false;
    subjectDiv.innerHTML = "";
    questionDiv.innerHTML = "";
    answerDiv.innerHTML = "";
    timerDiv.innerHTML = "<i class='fas fa-stopwatch'></i> 0";
    isCorrect.innerHTML = "";
    textInput.value = "";
    textInput.setAttribute('disabled', true);
    const interval_id = window.setInterval(function(){}, Number.MAX_SAFE_INTEGER);
    for (var i = 0; i < interval_id; i++){
        window.clearInterval(i);
    }
}

function questionDone() {
    const interval_id = window.setInterval(function(){}, Number.MAX_SAFE_INTEGER);
    for (var i = 0; i < interval_id; i++){
        window.clearInterval(i);
    }
    startTimer();
}

function startTimer() {
    value = 0;
    timer = setInterval(function() {
        if(value < 11) {
            timerDiv.innerHTML = "<i class='fas fa-stopwatch'></i> " + String(value);
        } else {
            checkQuestion();
        };
        value++;
    }, 1000);
}

function buzzIn() {
    if(!hasBuzzedIn){
        hasBuzzedIn = true;
        textInput.removeAttribute('disabled');
        textInput.focus();
        const interval_id = window.setInterval(function(){}, Number.MAX_SAFE_INTEGER);
        for (var i = 0; i < interval_id; i++){
            window.clearInterval(i);
        }
        questionDiv.innerHTML += "<i class='fas fa-solid fa-bell'></i>";
        timeForBuzz();
    }
}

function timeForBuzz() {
    value = 0;
    timer = setInterval(function() {
        if(value < 11) {
            timerDiv.innerHTML = "<i class='fas fa-stopwatch'></i> " + String(value);
        } else {
            checkQuestion();
        };
        value++;
    }, 1000);
}

function checkQuestion() {
    
    var guess = textInput.value;
    if(guess === undefined || guess === null || guess === "") {
        incorrectAnswer();
    } else {
        var answer = current["answer"];
        similarity = stringSimilarity.compareTwoStrings(guess.toLowerCase(), answer.toLowerCase());
        const interval_id = window.setInterval(function(){}, Number.MAX_SAFE_INTEGER);
        for (var i = 0; i < interval_id; i++){
            window.clearInterval(i);
        }
        if (similarity >= 0.6) {
            correctAnswer();
        } else {
            incorrectAnswer();
        }
    }
}

function correctAnswer() {
    questionDiv.innerHTML = current["question"];
    isCorrect.innerHTML = "<span id='correct'>Correct!</span> Official Answer: " + current["answer"] + " | <a target='_blank' href='https://kbpractice.com/report?id=" + current["ID"] + "'>Report</a>";
    textInput.setAttribute('disabled', true);
}

function incorrectAnswer() {
    questionDiv.innerHTML = current["question"];
    isCorrect.innerHTML = "<span id='incorrect'>Incorrect!</span> Answer: " + current["answer"] + " | <a target='_blank' href='https://kbpractice.com/report?id=" + current["ID"] + "'>Report</a>";
    textInput.setAttribute('disabled', true);
}


document.addEventListener("keydown", (event) => {
    if(textInput !== document.activeElement){
        if (event.key === " ") {
            buzzIn();
        } else if(event.key === "Enter" || event.key === "ArrowRight") {
            fetchQuestion();
        }
    } else if(event.key === "Enter") {
        checkQuestion();
    }
}
)

function dark() {
    darkMode.blur()
    if(document.body.classList.contains('light')){
        document.body.classList.replace('light', 'dark');
    } else {
        document.body.classList.replace('dark', 'light');
    }
}
