<?php

//include file for opening connections to the MySQL database

//open connection
function OpenCon() {
    //information: address, username, password, and database name
    $dbhost = "70.32.23.82";
    $dbuser = "eduriaor_root";
    $dbpass = "puLLedpOrk";
    $db = "eduriaor_KBOnline";

    //use mysqli built in function to open connection, throw error if it doesn't work
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die ("Connect failed: %s\n". $conn -> error);

    return $conn;
}

//close connection
function CloseCon($conn) {
    $conn -> close();
}

$conn = OpenCon();
$query = "select * from `Questions` group by `Question` ORDER BY Rand() LIMIT 1";
$result = mysqli_query($conn, $query);
$result = mysqli_fetch_all($result, MYSQLI_ASSOC);
$result = $result[0];

$subject = $result["Subject"];
$question = $result["Question"];
$answer = $result["Answer"];
$id = $result["ID"];

function json($status, $data) {
        $cors = "*";
        header("Access-Control-Allow-Origin: $cors");
        header('Content-Type: application/json; charset=utf-8');
        http_response_code($status);
        echo json_encode($data);
}
    
    
json(200, [
    "ID" => $id,
	"subject" => $subject,
  	"question" => $question,
  	"answer" => $answer
]);


