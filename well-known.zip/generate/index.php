<?php
function OpenCon() {
    //information: address, username, password, and database name
    $dbhost = "70.32.23.82";
    $dbuser = "eduriaor_root";
    $dbpass = "puLLedpOrk";
    $db = "eduriaor_KBOnline";

    //use mysqli built in function to open connection, throw error if it doesn't work
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die ("Connect failed: %s\n". $conn -> error);

    return $conn;
}

//close connection
function CloseCon($conn) {
    $conn -> close();
}

$num;

if(isset($_GET["num"])) {
    $num = $_GET["num"];
} else {
    $num = 10;
}

$conn = OpenCon();
$query = "select * from `Questions` group by `Question` ORDER BY Rand() LIMIT $num";
$result = mysqli_query($conn, $query);
$result = mysqli_fetch_all($result, MYSQLI_ASSOC);



?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Generated Knowledge Bowl Questions</title>
    </head>
    <body>
        <form autocomplete="off" method="get" action="">
            <input name="num" type="text" placeholder="Number of Questions...">
            <button>Submit</button>
        </form>
        <div class="questions">
            <?php foreach(range(0, $num-1) as $number){
            $paper_number = $number+1;?>
            <div class="card">
                <span class="subject">
                    <?php echo "$paper_number. " . explode(".", $result[$number]["Subject"])[1];?>
                </span>
                <br>
                <span class="question">
                    <?php echo $result[$number]["Question"];?>
                </span>
                <div class="answer">
                    <?php echo $result[$number]["Answer"];?>
                </div>
            </div>
            <?php }; ?>
        </div>
    </body>
</html>