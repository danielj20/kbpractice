<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="title" content="KBPractice | Practice Knowledge Bowl Online">
    <meta name="description" content="KBPractice.com is the world's first online tool for individual practice of Knowledge Bowl, pulling from a database of over 10,000 questions.">
    <meta name="keywords" content="questions, knowledge, bowl, online, tool, individual, practice, quizbowl, quiz">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="English">
    <meta charset="UTF-8">
    <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style_v1_1.css">
    <link rel="icon" href="../favicon.png">
    <script src="https://kit.fontawesome.com/9d9b1c2a48.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.11.2/css/all.css" integrity="sha384-zrnmn8R8KkWl12rAZFt4yKjxplaDaT7/EUkKm7AovijfrQItFWR7O/JJn4DAa/gx" crossorigin="anonymous">

</head>
<body class="light">
<?php




include_once "connect.inc.php";
$conn = OpenCon();

$asql = "SELECT * FROM `Questions` WHERE 1;";
$aquery = mysqli_query($conn, $asql);
$topid = mysqli_num_rows($aquery);




$id = $_GET["id"];

$address = $_SERVER['REMOTE_ADDR'];

$getreports = "SELECT * FROM `Reports` WHERE `IP` = '$address' AND `ID` = $id;";
$getquery = mysqli_query($conn, $getreports);
$getresult = mysqli_fetch_all($getquery, MYSQLI_ASSOC);

$getquestion = "SELECT * FROM `Questions` WHERE `ID` = '$id';";
$qquery = mysqli_query($conn, $qquery);
$qresult = mysqli_fetch_all($qresult, MYSQLI_ASSOC);

if(empty($getresult) and $id <= $topid and is_numeric($id)){
    $sql = "INSERT INTO `Reports` (`IP`, `ID`) VALUES ('$address', '$id');";
    $query = mysqli_query($conn, $sql);?>
    <title>Successful Report | KBPractice</title>
    <div id="full-container">
        <h1>Successful report</h1>
        <p>You have successfully reported this question. Just so you know, your IP was recorded anonymously to prevent bots and other hijacking while still allowing reporting without signing up for some service. With enough reports, this question will be modified or removed.</p>
    <script src="https://unpkg.com/string-similarity/umd/string-similarity.min.js"></script>
    <script src="index.js"></script>
    <?php
} else {?>
    <title>Unsuccessful Report | KBPractice</title>
    <div id="full-container">
        <h1>Unsuccessful report</h1>
        <p>Either you have already reported this, the ID does not exist, or something else went wrong. Try again later.</p>
    <script src="https://unpkg.com/string-similarity/umd/string-similarity.min.js"></script>
    <script src="index.js"></script>
<?php } ?>
</body>