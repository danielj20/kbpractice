<?php
//include file for opening connections to the MySQL database

//open connection
function OpenCon() {
    //information: address, username, password, and database name
    $dbhost = "70.32.23.82";
    $dbuser = "eduriaor_root";
    $dbpass = "puLLedpOrk";
    $db = "eduriaor_KBOnline";

    //use mysqli built in function to open connection, throw error if it doesn't work
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die ("Connect failed: %s\n". $conn -> error);

    return $conn;
}

//close connection
function CloseCon($conn) {
    $conn -> close();
}